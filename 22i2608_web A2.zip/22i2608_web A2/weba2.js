const apiKey = '87767364fc15ee9d69b4460c85b247ea';
const apiUrl = 'https://api.openweathermap.org/data/2.5/weather';
const forecastUrl = 'https://api.openweathermap.org/data/2.5/forecast';

const locationInput = document.getElementById('locationInput');
const searchButton = document.getElementById('searchButton');
const locationElement = document.getElementById('location');
const temperatureElement = document.getElementById('temperature');
const descriptionElement = document.getElementById('description');
const weatherIconElement = document.getElementById('weatherIcon');

// Chart elements
let barChart, doughnutChart, lineChart;
const chartContainer = document.querySelector('.chart-container'); // Get the chart container

searchButton.addEventListener('click', () => {
    const location = locationInput.value;
    if (location) {
        fetchWeather(location);
        fetchForecast(location);
    } else {
        alert("Please enter a city name");
    }
});

function fetchWeather(location) {
    const url = `${apiUrl}?q=${location}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error("Weather data not available for this city.");
            }
            return response.json();
        })
        .then(data => {
            // Display weather data
            locationElement.textContent = data.name;
            temperatureElement.textContent = `${Math.round(data.main.temp)}°C`;
            descriptionElement.textContent = data.weather[0].description;

            // Set the weather icon
            if (data.weather && data.weather.length > 0) {
                const status = data.weather[0];
                setWeatherIcon(status.id);
            }
        })
        .catch(error => {
            console.error('Error fetching weather data:', error);
            alert("Could not retrieve weather data. Please try again.");
        });
}

function fetchForecast(location) {
    const url = `${forecastUrl}?q=${location}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            const temps = [];
            const weatherConditions = [];

            // Loop over 5 days (8 * 3-hour intervals per day)
            for (let i = 0; i < data.list.length; i += 8) {
                const forecast = data.list[i];
                temps.push(forecast.main.temp);
                weatherConditions.push(forecast.weather[0].main);
            }

            // Show chart container after fetching data
            chartContainer.style.display = 'flex'; // Show chart container
            // Update charts
            updateCharts(temps, weatherConditions);
        })
        .catch(error => console.error("Error fetching forecast:", error));
}

function updateCharts(temps, weatherConditions) {
    // Data for weather conditions (count sunny, cloudy, etc.)
    const weatherCounts = weatherConditions.reduce((acc, condition) => {
        acc[condition] = (acc[condition] || 0) + 1;
        return acc;
    }, {});

    const labels = ["Day 1", "Day 2", "Day 3", "Day 4", "Day 5"];

    // Bar Chart (Vertical)
    const barCtx = document.getElementById('barChart').getContext('2d');
    if (barChart) barChart.destroy();
    barChart = new Chart(barCtx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Temperature (°C)',
                data: temps,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            animation: {
                delay: 500
            }
        }
    });

    // Doughnut Chart (Weather Conditions)
    const doughnutCtx = document.getElementById('doughnutChart').getContext('2d');
    if (doughnutChart) doughnutChart.destroy();
    doughnutChart = new Chart(doughnutCtx, {
        type: 'doughnut',
        data: {
            labels: Object.keys(weatherCounts),
            datasets: [{
                label: 'Weather Conditions',
                data: Object.values(weatherCounts),
                backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF'],
                hoverBackgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF']
            }]
        },
        options: {
            animation: {
                delay: 500
            }
        }
    });

    // Line Chart (Temperature Changes)
    const lineCtx = document.getElementById('lineChart').getContext('2d');
    if (lineChart) lineChart.destroy();
    lineChart = new Chart(lineCtx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Temperature (°C)',
                data: temps,
                fill: false,
                borderColor: '#FF6384',
                tension: 0.1
            }]
        },
        options: {
            animation: {
                duration: 2000,
                easing: 'easeOutBounce'
            }
        }
    });
}

function setWeatherIcon(statusId) {
    const photo = weatherIconElement;
    photo.style.display = "block";

    if (statusId >= 200 && statusId < 300) {
        photo.setAttribute('src', 'https://openweathermap.org/img/wn/11d@2x.png');
    } else if (statusId >= 300 && statusId < 400) {
        photo.setAttribute('src', 'https://openweathermap.org/img/wn/09d@2x.png');
    } else if (statusId >= 500 && statusId < 600) {
        photo.setAttribute('src', 'https://openweathermap.org/img/wn/10d@2x.png');
    } else if (statusId >= 600 && statusId < 700) {
        photo.setAttribute('src', 'https://openweathermap.org/img/wn/13d@2x.png');
    } else if (statusId >= 700 && statusId < 800) {
        photo.setAttribute('src', 'https://openweathermap.org/img/wn/50d@2x.png');
    } else if (statusId === 800) {
        photo.setAttribute('src', 'https://openweathermap.org/img/wn/01d@2x.png');
    } else if (statusId > 800 && statusId < 900) {
        photo.setAttribute('src', 'https://openweathermap.org/img/wn/03d@2x.png');
    } else {
        photo.setAttribute('src', 'https://openweathermap.org/img/wn/01d@2x.png');
    }
}
